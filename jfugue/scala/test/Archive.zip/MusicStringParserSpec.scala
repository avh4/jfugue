package org.jfugue.parsers.msp5

import org.specs._
import org.jfugue.Environment

object MusicStringParserSpec extends Specification("MusicStringParser") {
  val p = new MusicStringParser
  val env = new Environment()

  "A MusicStringParser" should {

    "parse \"V5\" as List(Voice(LByte(5)))" in {
      val r = p.parse("V5")
      r match {
	case p.Success(r,_) => r.toString mustEqual "List(Voice(LByte(5)))"
	case x => fail(x.toString)
      }
    }

  }

}
